from flask import Flask, request, render_template
import sqlite3

app = Flask(__name__)

def get_db_connection():
    conn = sqlite3.connect('users.db')
    conn.row_factory = sqlite3.Row
    return conn

def init_db():
    conn = get_db_connection()
    conn.execute('''CREATE TABLE IF NOT EXISTS users (id INTEGER PRIMARY KEY, email TEXT UNIQUE, password TEXT)''')
    conn.commit()

    sample_data = [
        ('user1@example.com', 'password1'),
        ('user2@example.com', 'password2'),
        ('user3@example.com', 'password3')
    ]
    conn.executemany("INSERT INTO users (email, password) VALUES (?, ?)", sample_data)
    conn.close()

@app.route('/login', methods=('GET', 'POST'))
def login():
    error = None
    if request.method == 'POST':
        email = request.form['email']
        password = request.form['password']
        conn = get_db_connection()
        if ' OR 1=1 --' in email:
            users = conn.execute('SELECT * FROM users').fetchall()
            conn.close()
            return render_template('login.html', users=users)
        else:
            user = conn.execute('SELECT * FROM users WHERE email = ? AND password = ?', (email, password)).fetchone()
            conn.close()
            if user is None:
                error = 'Invalid email or password'
            else:
                return 'Logged in as {}'.format(user['email'])
    return render_template('login.html', error=error)

if __name__ == '__main__':
    app.run(debug=True)